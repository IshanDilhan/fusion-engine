"""Standalone inference for fusion-gbt v6, no mlflow/cloudpickle/sklearn
required -- just lightgbm, numpy, pandas. Reproduces
mlflow.pyfunc.load_model(...).predict(df) exactly (verified against the
original mlflow model on real clip_features.parquet rows).
"""
import json
import os

import lightgbm as lgb
import numpy as np
import pandas as pd

_HERE = os.path.dirname(__file__)

with open(os.path.join(_HERE, "feature_names.json")) as f:
    FEATURE_NAMES = json.load(f)
with open(os.path.join(_HERE, "classes.json")) as f:
    CLASSES = json.load(f)
with open(os.path.join(_HERE, "config.json")) as f:
    F02_SAFETY_THRESHOLD = json.load(f)["f02_safety_threshold"]

_booster = lgb.Booster(model_file=os.path.join(_HERE, "booster.txt"))
_F02_IDX = CLASSES.index("F02")


def predict(model_input: pd.DataFrame) -> pd.Series:
    X = model_input[FEATURE_NAMES]
    proba = _booster.predict(X)  # (n_samples, n_classes), columns in CLASSES order
    argmax_idx = proba.argmax(axis=1)
    preds = np.array(CLASSES)[argmax_idx]
    escalate = proba[:, _F02_IDX] >= F02_SAFETY_THRESHOLD
    preds = np.where(escalate, "F02", preds)
    return pd.Series(preds, index=model_input.index)
