"""No-mlflow inference entry point for the fusion models.

Usage:
    python infer.py --model gbt --input features.parquet --output preds.csv
    python infer.py --model rule_based --input features.parquet --output preds.csv

Input must be a CSV/Parquet with the 34 fusion feature columns (see
gbt/feature_names.json). Output is a CSV with one "intent" column.

Deps: gbt needs `lightgbm`; rule_based needs only `numpy`+`pandas`.
No mlflow, cloudpickle, or scikit-learn required either way.
"""
import argparse
import os
import sys

import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "gbt"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "rule_based"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", choices=["gbt", "rule_based"], required=True)
    ap.add_argument("--input", required=True, help="CSV or Parquet with fusion feature columns")
    ap.add_argument("--output", required=True, help="CSV path to write predictions to")
    args = ap.parse_args()

    df = pd.read_parquet(args.input) if args.input.endswith(".parquet") else pd.read_csv(args.input)

    if args.model == "gbt":
        import gbt_infer
        preds = gbt_infer.predict(df)
    else:
        import rule_based_infer
        preds = rule_based_infer.predict(df)

    pd.DataFrame({"intent": preds}).to_csv(args.output, index=False)
    print(f"wrote {len(preds)} predictions -> {args.output}")


if __name__ == "__main__":
    main()
