"""Standalone copy of fusion/rule_based.py's predict_intent() logic, with the
mlflow.pyfunc wrapper dropped -- this model has no learned parameters, so
there's nothing to unpickle. Needs only numpy/pandas. Reproduces
mlflow.pyfunc.load_model(...).predict(df) exactly for fusion-rule-based v4.
"""
import json
import os

import numpy as np
import pandas as pd

EMOTION_CLASSES = ["Surprise", "Fear", "Disgust", "Happy", "Sad", "Anger", "Neutral"]
GESTURE_CLASSES = ["wave", "point", "thumbs_up", "thumbs_down", "raise_hand",
                    "both_hands_up", "beckoning", "Unknown"]
MOTION_CLASSES = ["sitting", "standing", "walking", "stepping_back"]
CONTEXT_CLASSES = ["classroom", "kitchen"]

FEATURE_NAMES = (
    [f"emotion_{c}" for c in EMOTION_CLASSES] + ["emotion_max_confidence", "emotion_valid_fraction"]
    + [f"gesture_{c}" for c in GESTURE_CLASSES] + ["gesture_mean_confidence", "gesture_valid_fraction"]
    + [f"motion_{c}" for c in MOTION_CLASSES] + ["motion_max_confidence", "motion_valid_fraction"]
    + [f"context_{c}" for c in CONTEXT_CLASSES] + ["context_mean_confidence", "context_valid_fraction"]
    + ["missing_emotion", "missing_gesture", "missing_motion", "missing_context"]
)

with open(os.path.join(os.path.dirname(__file__), "config.json")) as f:
    DEFAULT_FALLBACK_INTENT = json.load(f)["fallback_intent"]


def _dominant(row, prefix, classes):
    if row.get(f"missing_{prefix}", 0.0) >= 1.0:
        return None
    vals = [row[f"{prefix}_{c}"] for c in classes]
    if max(vals) <= 0.0:
        return None
    return classes[int(np.argmax(vals))]


def predict_intent(row, fallback_intent=DEFAULT_FALLBACK_INTENT):
    emotion = _dominant(row, "emotion", EMOTION_CLASSES)
    gesture = _dominant(row, "gesture", GESTURE_CLASSES)
    motion = _dominant(row, "motion", MOTION_CLASSES)

    if gesture == "both_hands_up":
        if emotion == "Anger":
            return "F07"
        if emotion == "Neutral":
            return "F05"
        return "F02"

    if gesture == "Unknown":
        if emotion == "Sad":
            return "F10"
        if emotion == "Fear":
            return "F02"
        if emotion == "Neutral":
            return "F05"

    if gesture in ("thumbs_down", "thumbs_up"):
        if emotion == "Sad":
            return "F04"
        if emotion == "Anger":
            return "F07"
        if emotion == "Disgust":
            return "F08"
        if emotion == "Happy":
            return "F01"

    if gesture == "raise_hand":
        context = _dominant(row, "context", CONTEXT_CLASSES)
        if emotion == "Happy":
            return "F01" if context == "kitchen" else "F05"
        if emotion in ("Neutral", None):
            return "F04"

    if gesture == "beckoning":
        if emotion == "Neutral":
            return "F03"
        if emotion == "Sad":
            return "F04"

    if gesture == "point":
        if emotion == "Anger":
            if motion == "walking":
                return "F06"
            if motion == "standing":
                return "F07"
        if emotion == "Disgust":
            return "F06"
        if emotion in ("Happy", "Neutral"):
            return "F03"

    if gesture == "wave":
        return "F06" if emotion == "Anger" else "F01"

    if gesture is None:
        if emotion == "Fear":
            return "F02"
        if emotion == "Sad" and motion == "sitting":
            return "F04"
        if emotion in ("Neutral", None) and motion == "walking":
            return "F06"

    return fallback_intent


def predict(model_input: pd.DataFrame) -> pd.Series:
    return model_input[FEATURE_NAMES].apply(lambda row: predict_intent(row), axis=1)
